# GREENBUSINESS — Production Build Specification v1.0

**Estado:** Canon de implementación  
**Objetivo:** eliminar ambigüedad entre diseño e implementación y permitir construir el vertical slice sin redefinir arquitectura.

---

# 1. Definition of Ready

Antes de iniciar desarrollo:
- repositorio Git creado;
- Docker instalado;
- PostgreSQL y Redis disponibles vía Compose;
- variables de entorno definidas;
- CI ejecutando lint + tests;
- documentación canon incluida en `/docs`.

---

# 2. Monorepo

```text
greenbusiness/
├── apps/
│   ├── web/
│   └── admin/
├── services/
│   └── api/
├── packages/
│   ├── contracts/
│   ├── game-config/
│   ├── analytics-schema/
│   └── design-tokens/
├── infra/
│   ├── nginx/
│   ├── docker/
│   └── monitoring/
├── docs/
├── docker-compose.yml
├── .env.example
├── Makefile
└── README.md
```

---

# 3. Backend package structure

```text
services/api/app/
├── main.py
├── config.py
├── db/
│   ├── base.py
│   ├── session.py
│   └── models.py
├── common/
│   ├── errors.py
│   ├── ids.py
│   ├── time.py
│   ├── security.py
│   └── idempotency.py
├── auth/
├── users/
├── player/
├── genetics/
├── crops/
├── inventory/
├── economy/
├── contracts/
├── progression/
├── upgrades/
├── missions/
├── employees/
├── clubs/
├── liveops/
├── analytics/
├── payments/
├── antifraud/
└── notifications/
```

Cada módulo utiliza:
- router.py
- service.py
- repository.py
- schemas.py
- models.py cuando corresponde
- tests/

No se permite lógica de negocio directamente en routers.

---

# 4. IDs y tiempo

Todos los IDs públicos: UUIDv7.

Todos los timestamps:
- UTC;
- `timestamptz`;
- generados por servidor.

Nunca confiar en reloj cliente.

---

# 5. SQL schema mínimo

## users
```sql
CREATE TABLE users (
  id UUID PRIMARY KEY,
  email CITEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_login_at TIMESTAMPTZ
);
```

## player_profiles
```sql
CREATE TABLE player_profiles (
  id UUID PRIMARY KEY,
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  display_name VARCHAR(32) NOT NULL,
  level INTEGER NOT NULL DEFAULT 1 CHECK (level >= 1),
  xp BIGINT NOT NULL DEFAULT 0 CHECK (xp >= 0),
  reputation BIGINT NOT NULL DEFAULT 0 CHECK (reputation >= 0),
  tutorial_step INTEGER NOT NULL DEFAULT 0,
  tutorial_completed BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## wallets
```sql
CREATE TABLE wallets (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  currency VARCHAR(32) NOT NULL,
  balance BIGINT NOT NULL DEFAULT 0 CHECK (balance >= 0),
  version BIGINT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, currency)
);
```

## ledger_entries
```sql
CREATE TABLE ledger_entries (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  wallet_id UUID NOT NULL REFERENCES wallets(id),
  currency VARCHAR(32) NOT NULL,
  amount BIGINT NOT NULL CHECK (amount > 0),
  direction VARCHAR(8) NOT NULL CHECK (direction IN ('credit','debit')),
  balance_before BIGINT NOT NULL,
  balance_after BIGINT NOT NULL,
  source_type VARCHAR(64) NOT NULL,
  source_id UUID,
  idempotency_key VARCHAR(128) NOT NULL,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, idempotency_key)
);
```

## genetics
```sql
CREATE TABLE genetics (
  id UUID PRIMARY KEY,
  slug VARCHAR(64) UNIQUE NOT NULL,
  name VARCHAR(64) NOT NULL,
  rarity VARCHAR(24) NOT NULL,
  grow_seconds INTEGER NOT NULL CHECK (grow_seconds > 0),
  seed_cost BIGINT NOT NULL CHECK (seed_cost >= 0),
  base_yield INTEGER NOT NULL CHECK (base_yield > 0),
  quality_min INTEGER NOT NULL CHECK (quality_min BETWEEN 0 AND 100),
  quality_max INTEGER NOT NULL CHECK (quality_max BETWEEN 0 AND 100),
  unlock_level INTEGER NOT NULL DEFAULT 1,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  config_version VARCHAR(64) NOT NULL
);
```

## crop_slots
```sql
CREATE TABLE crop_slots (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  facility_id UUID,
  slot_index INTEGER NOT NULL,
  unlock_level INTEGER NOT NULL,
  status VARCHAR(24) NOT NULL DEFAULT 'available',
  UNIQUE(user_id, slot_index)
);
```

## crop_instances
```sql
CREATE TABLE crop_instances (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  slot_id UUID NOT NULL REFERENCES crop_slots(id),
  genetic_id UUID NOT NULL REFERENCES genetics(id),
  started_at TIMESTAMPTZ NOT NULL,
  ready_at TIMESTAMPTZ NOT NULL,
  care_bonus INTEGER NOT NULL DEFAULT 0,
  quality_seed BIGINT NOT NULL,
  state VARCHAR(24) NOT NULL,
  harvested_at TIMESTAMPTZ,
  config_version VARCHAR(64) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## inventory_items
```sql
CREATE TABLE inventory_items (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  item_type VARCHAR(32) NOT NULL,
  item_id UUID NOT NULL,
  quantity BIGINT NOT NULL CHECK (quantity >= 0),
  quality INTEGER,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## contracts
```sql
CREATE TABLE contracts (
  id UUID PRIMARY KEY,
  slug VARCHAR(64) UNIQUE NOT NULL,
  buyer_name VARCHAR(96) NOT NULL,
  required_item VARCHAR(64) NOT NULL,
  required_quantity INTEGER NOT NULL,
  min_quality INTEGER,
  required_traits JSONB NOT NULL DEFAULT '[]'::jsonb,
  duration_seconds INTEGER NOT NULL,
  reward_cash BIGINT NOT NULL,
  reward_xp BIGINT NOT NULL,
  reward_reputation BIGINT NOT NULL,
  unlock_level INTEGER NOT NULL DEFAULT 1,
  enabled BOOLEAN NOT NULL DEFAULT TRUE
);
```

## player_contracts
```sql
CREATE TABLE player_contracts (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  contract_id UUID NOT NULL REFERENCES contracts(id),
  status VARCHAR(24) NOT NULL,
  accepted_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  reward_snapshot JSONB NOT NULL,
  requirements_snapshot JSONB NOT NULL
);
```

## outbox_events
```sql
CREATE TABLE outbox_events (
  id UUID PRIMARY KEY,
  event_type VARCHAR(96) NOT NULL,
  aggregate_id UUID,
  payload JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ
);
```

---

# 6. SQLAlchemy rules

- AsyncSession.
- Repository pattern.
- `SELECT ... FOR UPDATE` para wallets, crops y contratos.
- No usar `session.commit()` dentro de repositories.
- Transaction boundary en service layer.
- DB constraints duplican invariants importantes.

---

# 7. Pydantic schemas

Convenciones:
- `*Create`
- `*Update`
- `*Read`
- `*Response`

Ejemplo:

```python
class PlantCropRequest(BaseModel):
    genetic_slug: str

class CropResponse(BaseModel):
    id: UUID
    slot_id: UUID
    genetic_slug: str
    state: Literal["growing", "ready", "harvested", "cancelled"]
    started_at: datetime
    ready_at: datetime
```

---

# 8. Error contract

Todos los errores:

```json
{
  "error": {
    "code": "CROP_NOT_READY",
    "message": "Crop is not ready to harvest.",
    "details": {},
    "request_id": "..."
  }
}
```

Códigos iniciales:
- AUTH_INVALID_CREDENTIALS
- AUTH_TOKEN_EXPIRED
- PLAYER_NOT_FOUND
- INSUFFICIENT_FUNDS
- SLOT_LOCKED
- SLOT_OCCUPIED
- GENETIC_LOCKED
- CROP_NOT_FOUND
- CROP_NOT_READY
- CROP_ALREADY_HARVESTED
- CONTRACT_NOT_FOUND
- CONTRACT_EXPIRED
- CONTRACT_REQUIREMENTS_NOT_MET
- INVENTORY_INSUFFICIENT
- IDEMPOTENCY_CONFLICT
- RATE_LIMITED

---

# 9. API exacta del vertical slice

## POST /api/v1/auth/register
Input:
```json
{"email":"player@example.com","password":"...","display_name":"GreenBoss"}
```

Output:
```json
{"access_token":"...","refresh_token":"...","player":{}}
```

## GET /api/v1/player
Devuelve perfil, balances y unlocks principales.

## GET /api/v1/genetics
Devuelve solo genéticas desbloqueadas + próximas bloqueadas.

## GET /api/v1/crop-slots
Devuelve slots y cultivo asociado.

## POST /api/v1/crop-slots/{slot_id}/plant
Headers:
`Idempotency-Key`

Input:
```json
{"genetic_slug":"green-starter"}
```

Transaction:
1. lock wallet;
2. validar slot;
3. validar genética;
4. debitar semilla;
5. crear crop;
6. generar outbox;
7. commit.

## POST /api/v1/crops/{crop_id}/harvest
Headers:
`Idempotency-Key`

Transaction:
1. lock crop;
2. comprobar ownership;
3. comprobar ready_at;
4. calcular quality/yield;
5. crear/aumentar inventory;
6. marcar harvest;
7. XP si corresponde;
8. outbox;
9. commit.

## GET /api/v1/contracts/offers

## POST /api/v1/contracts/{id}/accept

## POST /api/v1/player-contracts/{id}/complete
Headers:
`Idempotency-Key`

Transaction:
1. lock contract;
2. validar deadline;
3. validar inventory;
4. consumir inventory;
5. acreditar wallet;
6. XP;
7. reputation;
8. status completed;
9. outbox;
10. commit.

## GET /api/v1/upgrades

## POST /api/v1/upgrades/{id}/purchase

---

# 10. Configuración inicial — economy_v1

```json
{
  "version": "economy_v1",
  "starting_cash": 500,
  "starting_green_credits": 0,
  "max_active_contracts": 3,
  "contract_refresh_seconds": 14400,
  "market_refresh_seconds": 21600,
  "quality_cap": 100,
  "minimum_wallet_balance": 0
}
```

---

# 11. Seed data — 12 genetics

```json
[
  {"slug":"green-starter","name":"Green Starter","rarity":"common","unlock_level":1,"grow_seconds":30,"seed_cost":25,"base_yield":5,"quality_min":40,"quality_max":50},
  {"slug":"easy-leaf","name":"Easy Leaf","rarity":"common","unlock_level":1,"grow_seconds":300,"seed_cost":40,"base_yield":8,"quality_min":40,"quality_max":52},
  {"slug":"city-green","name":"City Green","rarity":"common","unlock_level":2,"grow_seconds":900,"seed_cost":75,"base_yield":12,"quality_min":44,"quality_max":56},
  {"slug":"amber-mist","name":"Amber Mist","rarity":"uncommon","unlock_level":3,"grow_seconds":1800,"seed_cost":120,"base_yield":16,"quality_min":46,"quality_max":60},
  {"slug":"neon-dream","name":"Neon Dream","rarity":"uncommon","unlock_level":5,"grow_seconds":3600,"seed_cost":210,"base_yield":22,"quality_min":50,"quality_max":66},
  {"slug":"velvet-leaf","name":"Velvet Leaf","rarity":"uncommon","unlock_level":7,"grow_seconds":7200,"seed_cost":340,"base_yield":30,"quality_min":53,"quality_max":70},
  {"slug":"midnight","name":"Midnight","rarity":"rare","unlock_level":9,"grow_seconds":14400,"seed_cost":520,"base_yield":42,"quality_min":56,"quality_max":72},
  {"slug":"golden-haze","name":"Golden Haze","rarity":"rare","unlock_level":11,"grow_seconds":21600,"seed_cost":800,"base_yield":55,"quality_min":58,"quality_max":76},
  {"slug":"urban-legend","name":"Urban Legend","rarity":"rare","unlock_level":14,"grow_seconds":28800,"seed_cost":1250,"base_yield":72,"quality_min":61,"quality_max":80},
  {"slug":"emerald-crown","name":"Emerald Crown","rarity":"epic","unlock_level":16,"grow_seconds":43200,"seed_cost":1900,"base_yield":95,"quality_min":64,"quality_max":84},
  {"slug":"black-velvet","name":"Black Velvet","rarity":"epic","unlock_level":18,"grow_seconds":57600,"seed_cost":2900,"base_yield":125,"quality_min":68,"quality_max":88},
  {"slug":"aurora-prime","name":"Aurora Prime","rarity":"legendary","unlock_level":20,"grow_seconds":86400,"seed_cost":4500,"base_yield":170,"quality_min":72,"quality_max":92}
]
```

---

# 12. Traits seed

```json
[
  "fast","heavy","stable","premium","aromatic","resilient",
  "efficient","exotic","night","luxury","medical","creative","classic"
]
```

---

# 13. Level curve

Formula:
`XP_next = round(100 * level^1.45)`

Levels 1–20 se materializan en config para evitar recalcular reglas históricas.

---

# 14. Skill tree completo MVP

## Botany
- Efficient Seeds I/II/III: -3/-6/-9% seed cost.
- Quality Focus I/II/III: +2/+4/+6 quality.
- Better Yield I/II/III: +4/+8/+12% yield.
- Master Grower: +8 quality.

## Business
- Negotiator I/II/III: +3/+6/+9% contract reward.
- Client Network: +1 visible offer.
- Reputation I/II/III: +5/+10/+15% reputation.
- Executive: +10% premium contract chance.

## Operations
- Faster Cycle I/II/III: -3/-6/-9% grow time.
- Staff Efficiency I/II/III: +5/+10/+15% employee effect.
- Logistics I/II/III: +5/+10/+15% inventory capacity.
- Automation: unlock auto-replant preset.

---

# 15. Upgrades MVP

```json
[
  {"slug":"lights-1","category":"lights","level":1,"cost_cash":500,"effects":{"quality":2}},
  {"slug":"lights-2","category":"lights","level":2,"cost_cash":900,"effects":{"quality":4}},
  {"slug":"lights-3","category":"lights","level":3,"cost_cash":1620,"effects":{"quality":6}},
  {"slug":"tables-1","category":"tables","level":1,"cost_cash":650,"effects":{"slots":1}},
  {"slug":"environment-1","category":"environment","level":1,"cost_cash":900,"effects":{"yield_pct":5}},
  {"slug":"storage-1","category":"storage","level":1,"cost_cash":750,"effects":{"capacity_pct":10}},
  {"slug":"workstation-1","category":"workstation","level":1,"cost_cash":1200,"effects":{"employee_effect_pct":5}}
]
```

---

# 16. Tutorial state machine

```text
0 CREATED
1 INTRO_SEEN
2 STARTER_PLANTED
3 STARTER_READY
4 STARTER_HARVESTED
5 PHONE_OPENED
6 FIRST_CONTRACT_ACCEPTED
7 FIRST_CONTRACT_COMPLETED
8 FIRST_UPGRADE_BOUGHT
9 SECOND_CROP_STARTED
10 COMPLETE
```

El backend valida cada transición.

---

# 17. Misiones iniciales

1. First Seed — plantar Green Starter.
2. First Harvest — cosechar.
3. First Customer — completar contrato.
4. Better Light — comprar mejora.
5. Two at Once — mantener 2 cultivos activos.
6. City Green — cosechar nueva genética.
7. Quality Matters — cosechar quality ≥55.
8. Growing Demand — completar 3 contratos.
9. Expand — desbloquear slot.
10. New Contacts — completar specialised contract.

Hasta 25 en MVP siguiendo el mismo sistema data-driven.

---

# 18. Contracts seed — patrón

Contrato 1:
```json
{
  "slug":"tutorial-first-sale",
  "buyer_name":"Milo Green",
  "required_item":"green-starter",
  "required_quantity":5,
  "min_quality":0,
  "required_traits":[],
  "duration_seconds":3600,
  "reward_cash":150,
  "reward_xp":100,
  "reward_reputation":10,
  "unlock_level":1
}
```

Contrato 2:
```json
{
  "slug":"corner-order",
  "buyer_name":"Corner Café",
  "required_item":"easy-leaf",
  "required_quantity":8,
  "min_quality":45,
  "required_traits":[],
  "duration_seconds":7200,
  "reward_cash":180,
  "reward_xp":70,
  "reward_reputation":7,
  "unlock_level":1
}
```

Contrato 3:
```json
{
  "slug":"urban-aroma",
  "buyer_name":"Urban Leaf",
  "required_item":"neon-dream",
  "required_quantity":20,
  "min_quality":60,
  "required_traits":["aromatic"],
  "duration_seconds":28800,
  "reward_cash":700,
  "reward_xp":180,
  "reward_reputation":20,
  "unlock_level":5
}
```

El resto se carga desde JSON y se balancea mediante remote config.

---

# 19. Deterministic RNG

```python
def deterministic_seed(secret: bytes, user_id: UUID, crop_id: UUID, config_version: str) -> int:
    payload = f"{user_id}:{crop_id}:{config_version}".encode()
    digest = hmac.new(secret, payload, hashlib.sha256).digest()
    return int.from_bytes(digest[:8], "big")
```

Nunca enviar seed secreta al cliente.

---

# 20. Harvest algorithm

```python
async def harvest_crop(user_id, crop_id, idem_key):
    async with transaction():
        crop = await crops.lock_for_update(crop_id)

        assert crop.user_id == user_id
        assert crop.state != "harvested"
        assert utcnow() >= crop.ready_at

        genetic = await genetics.get_snapshot(crop)
        rng = deterministic_rng(crop)

        quality = calculate_quality(...)
        yield_qty = calculate_yield(...)

        await inventory.credit(...)
        crop.state = "harvested"
        crop.harvested_at = utcnow()

        await progression.add_harvest_xp(...)
        await outbox.publish("crop.harvested", ...)

    return HarvestResult(...)
```

---

# 21. Idempotency design

Tabla:
```sql
CREATE TABLE idempotency_records (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL,
  key VARCHAR(128) NOT NULL,
  request_hash VARCHAR(64) NOT NULL,
  status_code INTEGER,
  response_body JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL,
  UNIQUE(user_id, key)
);
```

Misma key + mismo body:
retornar respuesta almacenada.

Misma key + body distinto:
HTTP 409 IDEMPOTENCY_CONFLICT.

---

# 22. Frontend state

Zustand solo para:
- UI state;
- scene state;
- temporary selections.

TanStack Query para:
- server state;
- caching;
- invalidation.

Nunca mantener saldo autoritativo solo en Zustand.

---

# 23. Phaser scenes

```text
BootScene
PreloadScene
GrowRoomScene
```

GrowRoomScene:
- render de room;
- crop slots;
- plant sprites;
- interaction hotspots;
- animation feedback.

UI compleja permanece en React/Next.js sobre canvas.

---

# 24. Responsive targets

Primario:
- 390×844 móvil.
- 1080×2400 Android moderno.

Secundario:
- 1366×768.
- 1920×1080.

La escena Phaser usa scale FIT y safe-area awareness.

---

# 25. Admin v1

Funciones mínimas:
- listar jugadores;
- ver wallets;
- inspeccionar ledger;
- editar genetics config;
- editar contracts;
- activar/desactivar content;
- grants manuales con reason obligatorio;
- compensaciones idempotentes;
- feature flags;
- LiveOps calendar.

Toda mutación admin va a audit log.

---

# 26. Analytics taxonomy

Eventos obligatorios:
- session_started
- tutorial_started
- tutorial_step
- tutorial_completed
- crop_started
- crop_care
- crop_ready
- crop_harvested
- contract_offered
- contract_accepted
- contract_completed
- contract_expired
- upgrade_purchased
- skill_unlocked
- employee_hired
- currency_source
- currency_sink
- level_up
- club_joined
- club_contribution
- store_opened
- purchase_started
- purchase_completed

Propiedades comunes:
- event_id
- user_id
- session_id
- app_version
- platform
- config_version
- timestamp_server
- player_level

---

# 27. CI/CD

Pull request:
1. Python lint.
2. TypeScript lint.
3. Backend unit tests.
4. Frontend unit tests.
5. DB migration check.
6. Build API.
7. Build web.

Main:
1. todo lo anterior;
2. build containers;
3. vulnerability scan;
4. deploy staging;
5. smoke tests.

Production:
manual approval inicialmente.

---

# 28. Git strategy

`main` siempre deployable.

Branches cortas:
`feat/...`
`fix/...`
`chore/...`

No rama develop permanente.

---

# 29. Docker Compose services

- postgres
- redis
- api
- worker
- web
- admin
- nginx

Opcional dev:
- mailpit
- pgadmin

---

# 30. Nginx routes

```text
/                 → web:3000
/admin            → admin:3000
/api/             → api:8000
/health           → api health
```

Headers:
- HSTS en producción.
- X-Content-Type-Options.
- Referrer-Policy.
- CSP.

---

# 31. Health endpoints

`GET /health/live`
- proceso vivo.

`GET /health/ready`
- DB reachable.
- Redis reachable.

No exponer secretos ni detalles internos.

---

# 32. Backups

Production:
- daily snapshot;
- WAL continuous/PITR;
- 30 días retention;
- restore test mensual.

RPO objetivo <15 min.
RTO objetivo <2 h.

---

# 33. Vertical Slice Definition of Done

Debe existir un build desplegado donde un usuario pueda:
1. registrarse;
2. crear perfil;
3. ver su growroom;
4. plantar Green Starter;
5. pagar 25 cash;
6. cerrar navegador;
7. volver;
8. encontrar planta ready;
9. cosechar;
10. recibir inventory;
11. aceptar contrato;
12. entregar inventario;
13. recibir cash/XP/reputation;
14. comprar upgrade;
15. ver efecto de la mejora;
16. cerrar y volver sin perder estado.

Tests automáticos obligatorios:
- double plant;
- double harvest;
- double contract complete;
- insufficient cash;
- invalid slot;
- early harvest;
- idempotent replay;
- concurrent harvest;
- persistence after restart.

---

# 34. Fases de implementación

## Phase 0 — Foundation
Repo, Docker, CI, Postgres, Redis, FastAPI, Next.js, migrations, health.

## Phase 1 — Identity
Auth, sessions, profile, starter wallets, initial slots.

## Phase 2 — Economy Kernel
Wallet, ledger, idempotency, transaction helpers, audit trail.

## Phase 3 — Crop Vertical Slice
Genetics config, planting, timers, harvest, deterministic RNG.

## Phase 4 — Inventory + Contracts
Inventory, contract offers, completion, rewards.

## Phase 5 — Progression
XP, levels, upgrades, unlocks, tutorial.

## Phase 6 — UX polish
Phaser room, animations, responsive shell, notifications.

## Phase 7 — Instrumentation
Analytics, Sentry, dashboards, admin tools.

## Phase 8 — Meta
Skills, employees, missions.

## Phase 9 — Social
Clubs y weekly project.

## Phase 10 — Monetization
Cosmetics, Green Credits, store verification.

## Phase 11 — LiveOps
Seasons, events, remote config calendar.

---

# 35. Stop conditions

No avanzar a Clubs si:
- harvest loop no es estable;
- ledger tiene inconsistencias;
- tutorial completion <70% en testing;
- core loop requiere explicación externa.

No avanzar a monetización si:
- D1/D7 todavía no se mide correctamente;
- economía no está instrumentada.

---

# 36. Production acceptance criteria

Backend:
- migrations reproducibles;
- >80% cobertura en economy/crops/contracts;
- no critical vulnerabilities;
- race tests pasan;
- rollback probado.

Frontend:
- PWA instalable;
- mobile first;
- LCP <2.5 s en objetivo;
- error boundaries;
- offline message claro.

Operations:
- staging;
- production;
- monitoring;
- alerts;
- backups;
- runbook.

Product:
- tutorial;
- 12 genetics;
- 20 levels;
- 20+ contracts;
- progression;
- first upgrades;
- analytics.

---

# 37. Primer objetivo de ingeniería

El primer milestone no es “MVP completo”.

Es:

**MILESTONE VS-01 — ECONOMIC LOOP PLAYABLE**

Incluye exclusivamente:
- auth;
- profile;
- wallet/ledger;
- 2 crop slots;
- 2 genetics;
- planting;
- 30 s + 5 min timers;
- harvest;
- inventory;
- 2 contracts;
- 1 upgrade;
- tutorial básico;
- analytics mínima.

Al finalizar VS-01 se evalúa si el loop merece expansión.

---

# 38. Canon técnico

Este Production Build Specification hereda y concreta:
1. GDD v1.0.
2. TDD + Economy v1.0.

En conflicto:
Production Build Specification manda sobre detalles técnicos.
GDD manda sobre intención de producto.
