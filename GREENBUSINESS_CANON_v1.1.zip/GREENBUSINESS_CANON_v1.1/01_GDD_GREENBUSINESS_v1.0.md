# GREENBUSINESS — Master Game Design Document v1.0

**Estado:** Canon inicial de producción  
**Versión:** 1.0  
**Fecha:** septiembre de 2026  
**Género:** Social Tycoon / Management / Idle / Collection / Light RPG  
**Modelo:** Free-to-play ético  
**Plataformas objetivo:** Web/PWA + Android → Steam → iOS  
**Audiencia:** Adultos, 18+  
**Perspectiva:** Isométrica 2.5D  
**Multijugador:** Asíncrono  
**Live service:** Sí  

## 1. Visión
GreenBusiness es un tycoon social donde empiezas con un pequeño cultivo botánico ficticio y construyes gradualmente una empresa completa, desarrollando genéticas, optimizando producción, cumpliendo contratos, contratando empleados, comprando locales, construyendo una marca y cooperando o compitiendo con otros empresarios.

Arco principal:

ROOM → BUSINESS → BRAND → NETWORK → EMPIRE

## 2. Pilares
1. Progresión visible.
2. Decisiones económicas.
3. Appointment gameplay sin castigo.
4. Colección genética.
5. Identidad del negocio.
6. Mundo vivo con LiveOps.

## 3. Core loop
ESCOGER GENÉTICA → PLANTAR → CRECIMIENTO OFFLINE → CARE ACTIONS OPCIONALES → COSECHAR → CALIDAD/TRAITS/YIELD → PROCESAR → VENDER/CONTRATO → DINERO/XP/REPUTACIÓN → REINVERTIR → MEJORAR → DESBLOQUEAR.

## 4. Meta loop
PRODUCIR → GANAR → MEJORAR → AUTOMATIZAR → EXPANDIR → ESPECIALIZARSE → DESBLOQUEAR DISTRITO → ABRIR NEGOCIO → CONSTRUIR MARCA → DOMINAR MERCADOS.

## 5. Primera sesión
- Crear avatar y negocio.
- Primer cultivo de 30 s.
- Primera cosecha.
- Primer contrato.
- Primera mejora.
- Segunda genética.
- Primer ciclo de 5–15 min.

## 6. Cultivo
Estados: seed → planted → vegetative → flowering → ready → harvested.

Atributos: genética, rareza, tiempo, yield, quality, traits, stability, market tags y mastery.

Care actions opcionales: inspección, optimización, tratamiento, mantenimiento y selección. Nunca destruyen la producción por ausencia.

## 7. Genetics
Rarezas: Common, Uncommon, Rare, Epic, Legendary, Exotic.

Traits iniciales: Fast, Heavy, Stable, Premium, Aromatic, Resilient, Efficient, Exotic, Night, Luxury, Medical, Creative, Classic.

Mastery desbloquea cosméticos, insignias y mejoras menores.

## 8. Breeding y phenotypes
Sistema mid-game. Permite cruzar líneas, descubrir phenotypes y estabilizar traits. Fuera del MVP inicial.

## 9. Procesado y contratos
Pipeline: HARVEST → PROCESS → PRODUCT → CONTRACT.

Cada contrato define cantidad, calidad, traits, deadline, recompensa y reputación.

## 10. Mercado
Mercado NPC dinámico con Supply, Demand, Price y Trend. No existe P2P en MVP.

## 11. Economía
Monedas:
- Cash: soft currency.
- Green Credits: premium, solo cosméticos/convenience limitado.

XP gobierna habilidades personales. Reputation gobierna clientes, distritos y negocio.

## 12. Skill tree
Tres ramas:
- Botany.
- Business.
- Operations.

## 13. Employees
Roles: grower, technician, seller, manager, researcher, logistics y marketing.

Traits: Perfectionist, Fast Learner, Negotiator, Night Owl, Efficient, Creative, Lucky, Reliable.

## 14. Instalaciones
Apartment → Growroom → Warehouse → Lab → Shop → HQ.

## 15. Distritos
Old Town, Industrial Zone, Downtown, Arts District, Night District, Luxury Hills, Harbor, Tech District.

## 16. Marca y decoración
Nombre, logo, color, packaging, tienda, uniformes, vehículos y decoración de interiores. Gran sink económico.

## 17. Social
Perfiles, amigos, visitas, reacciones, regalos limitados, clubs, rankings y eventos.

Clubs de 10–30 jugadores con level, reputation, objectives, HQ, projects y leaderboards.

## 18. Narrativa
Microhistorias mediante mensajes, NPC y contratos. El teléfono contiene Messages, Contacts, Contracts, Club, Market y Events.

## 19. LiveOps
Eventos, temporadas de 4–6 semanas, remote config, featured content, nuevos NPC, genéticas, decoración y retos de club.

## 20. Retención
- Minutos: cultivo/contratos.
- Horas: timers.
- Días: missions/market.
- Semanas: club projects.
- Meses: seasons.
- Largo plazo: collection + empire.

## 21. Monetización
- Season Pass.
- Cosmetic Packs.
- Decorations.
- Avatar cosmetics.
- Store skins.
- HQ skins.
- Premium presets.
- Supporter packs.

Sin P2W. Sin paid loot boxes. Sin Web3/NFT en MVP.

## 22. Endgame
Gestión de múltiples facilities, employees, brands, research, contracts, clubs y district markets. Franchise System para nuevas ciudades en vez de prestige clásico.

## 23. UX
HUD isométrico con negocio principal y navegación a Business, Market, Phone, Club y Profile.

Pantallas MVP:
Login, Character Creation, Main Growroom, Genetics, Inventory, Contracts, Market, Employees, Upgrades, Phone, Missions, Club, Profile, Store, Settings.

## 24. Arte y audio
Stylized premium isometric 2.5D, estética urbana/orgánica premium, no infantil. Audio lo-fi/chill/urban, feedback UI y ambientes de producción.

## 25. Stack
Next.js + Phaser + TypeScript.
FastAPI + PostgreSQL + Redis.
Docker + Nginx + CDN + Object Storage.

## 26. MVP
- 1 city district.
- 1 growroom.
- 12 genetics.
- 20 levels.
- 25 missions.
- 20 contracts.
- 3 skill branches.
- 15 upgrades.
- 6 employee archetypes.
- 40 decorations.
- Clubs.
- 1 weekly club challenge.
- Store.
- Analytics.
- Admin.

## 27. Fuera de MVP
PvP realtime, P2P marketplace, open chat, multiple cities, full breeding, NFT, blockchain, story campaign grande, 3D free-roam, vehicle system.

## 28. Roadmap
Phase 0 Foundation.
Phase 1 Vertical Slice.
Phase 2 Economy.
Phase 3 Meta.
Phase 4 Social.
Phase 5 LiveOps.
Phase 6 Monetization.
Phase 7 Alpha.

## 29. Canon
- Nombre: GreenBusiness.
- Género: Social Business Tycoon.
- Audiencia: 18+.
- Mundo ficticio.
- Isométrico 2.5D.
- Server-authoritative.
- Cross-platform.
- Clubs como núcleo social.
- Genetics como núcleo coleccionable.
- Contracts + dynamic market como núcleo económico.
- Skills + employees como capa RPG.
- Seasons como núcleo LiveOps.
