# GREENBUSINESS CANON v1.1

Incluye:
- Master Canon Index
- GDD v1.0
- TDD + Economy v1.0
- Production Build Specification v1.0
- Art Bible & Asset Production Specification v1.0
- VS-01 Asset Manifest Template

El siguiente milestone de producto es VS-01 — Economic Loop Playable.
El siguiente milestone visual es VS-01 Art Pack.
