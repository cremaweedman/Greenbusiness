# GREENBUSINESS — MASTER CANON INDEX

Versión: 1.0
Fecha: septiembre de 2026

## Documentos canónicos

1. `01_GDD_GREENBUSINESS_v1.0.md`
   - Producto, loops, sistemas, UX, social, LiveOps, monetización y alcance.

2. `02_TDD_ECONOMY_GREENBUSINESS_v1.0.md`
   - Arquitectura técnica, economía, seguridad, observabilidad, testing y roadmap técnico.

3. `03_PRODUCTION_BUILD_SPEC_GREENBUSINESS_v1.0.md`
   - Especificación ejecutable: SQL, endpoints, contratos, seeds, algorithms, CI/CD y criterios de aceptación.

## Orden de autoridad

- Intención y producto: GDD.
- Arquitectura y economía: TDD/Economy.
- Implementación concreta: Production Build Specification.

## Próximo paso

Iniciar `Phase 0 — Foundation` y después `VS-01 — Economic Loop Playable`.

No añadir sistemas nuevos al canon antes de validar el vertical slice.

4. `04_ART_BIBLE_AND_ASSET_SPEC_GREENBUSINESS_v1.0.md`
   - Dirección artística, cámara, personajes, plantas, entorno, UI, animación, VFX, audio, asset manifest y pipeline IA.

5. `05_VS01_ASSET_MANIFEST_TEMPLATE.json`
   - Plantilla inicial de seguimiento de assets del vertical slice.
