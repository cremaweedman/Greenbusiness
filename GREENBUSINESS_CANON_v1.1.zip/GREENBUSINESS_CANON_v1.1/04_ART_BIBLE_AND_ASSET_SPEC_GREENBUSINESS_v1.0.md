# GREENBUSINESS — Art Bible & Asset Production Specification v1.0

**Estado:** Canon visual de producción  
**Proyecto:** GreenBusiness  
**Depende de:** GDD v1.0, TDD/Economy v1.0, Production Build Specification v1.0  
**Objetivo:** definir de forma suficientemente precisa el lenguaje visual y el inventario de assets para producir un vertical slice coherente y escalar después al MVP sin rehacer arte.

---

# 1. Objetivo visual

GreenBusiness debe comunicar simultáneamente:

- negocio;
- cultivo;
- progresión;
- cultura urbana;
- tecnología accesible;
- coleccionismo;
- personalidad adulta;
- humor ligero;
- aspiración.

La identidad visual debe sentirse más cercana a una **marca premium de management game** que a un juego de cannabis caricaturesco.

No debe parecer:

- un clon de Weeds Social Club;
- un juego infantil;
- un simulador criminal oscuro;
- un idle genérico móvil;
- un farming game rural;
- una interfaz SaaS disfrazada de juego.

---

# 2. Dirección artística canónica

## 2.1 Estilo

**Stylized premium isometric 2.5D**

Características:

- formas limpias;
- volúmenes claros;
- detalle controlado;
- materiales estilizados;
- siluetas legibles;
- iluminación dramática pero funcional;
- UI moderna;
- personajes ligeramente exagerados;
- plantas claramente distinguibles;
- ambientes compactos y muy legibles.

Referencias conceptuales de lenguaje, no de copia:
- dioramas isométricos;
- management games contemporáneos;
- visualización arquitectónica estilizada;
- branding biotech/agrotech premium;
- nightlife urbana ligera;
- cultura startup con toque contracultural.

---

# 3. Cámara

## 3.1 Cámara principal

- Proyección: isométrica simulada.
- Ángulo horizontal equivalente: 35–45°.
- Pitch visual: 25–35°.
- Sin perspectiva extrema.
- Cámara fija durante gameplay base.
- Zoom limitado.

## 3.2 Escala

El jugador debe poder ver:
- toda la habitación;
- todos los slots;
- empleados;
- mejoras;
- objetos interactivos;
- estados principales.

## 3.3 Reglas

- Nunca ocultar un cultivo detrás de otro asset importante.
- Las interacciones deben tener espacio visual propio.
- Assets grandes se diseñan pensando en lectura a escala móvil.
- Los elementos decorativos jamás deben tapar feedback de gameplay.

---

# 4. Composición

La escena base se construye como un diorama.

Capas:
1. shell de habitación;
2. suelo;
3. paredes;
4. infraestructura;
5. muebles;
6. grow slots;
7. plantas;
8. empleados/NPC;
9. props;
10. VFX;
11. interaction overlays;
12. UI HTML/React.

---

# 5. Paleta

## 5.1 Base

- Charcoal / negro cálido.
- Verde bosque oscuro.
- Verde botánico.
- Crema cálido.
- Gris mineral.

## 5.2 Acentos

- Dorado suave: premium, progreso, calidad.
- Verde neón controlado: energía, active state, tecnología.
- Ámbar: producción, timers, alertas suaves.
- Azul petróleo: tecnología y laboratorio.
- Magenta tenue: nightlife / eventos.

## 5.3 Uso

No saturar toda la escena.

El color debe guiar:
- interactuable;
- ready;
- premium;
- rareza;
- recompensa;
- alerta.

---

# 6. Iluminación

## 6.1 Growroom inicial

- Ambiente oscuro pero legible.
- Luz principal suave superior.
- LEDs de cultivo como fuente secundaria.
- Acentos cálidos en zonas humanas.
- Contraste medio-alto.
- Sombras suaves.

## 6.2 Regla

La iluminación nunca debe hacer ilegibles:
- plantas;
- estados;
- objetos;
- affordances.

---

# 7. Materiales

Priorizar:
- metal pintado;
- plástico mate;
- madera oscura;
- vidrio;
- cerámica;
- tela;
- vegetación;
- hormigón;
- suelo técnico;
- cartón/packaging premium.

Evitar:
- texturas hiperrealistas;
- suciedad excesiva;
- materiales fotográficos;
- brillos plásticos baratos.

---

# 8. Diseño de plantas

Cada genética debe distinguirse por al menos tres variables:

1. silueta;
2. color/tinte;
3. densidad/forma de floración.

Variables secundarias:
- anchura de hoja;
- altura;
- internodo;
- copa;
- pigmentación;
- glow/partículas de rareza en UI;
- maceta/label.

Nunca representar morfología con precisión botánica educativa.

La estética es ficticia y estilizada.

---

# 9. Estados visuales de cultivo

Cada genética necesita como mínimo:

1. seed/empty slot indicator;
2. sprout;
3. vegetative;
4. flowering;
5. ready;
6. harvested/reset.

VS-01 puede compartir modelos base y usar tintes/variantes.

MVP deberá diferenciar mejor genéticas de alto valor.

---

# 10. Rareza visual

Rarezas:
- Common
- Uncommon
- Rare
- Epic
- Legendary
- Exotic

La rareza se comunica principalmente en UI y VFX.

No convertir la planta en objeto mágico absurdo.

Sistema sugerido:

Common:
- neutral.

Uncommon:
- green accent.

Rare:
- teal/blue accent.

Epic:
- violet accent.

Legendary:
- gold accent.

Exotic:
- iridescent accent.

---

# 11. 12 genéticas MVP

## 1. Green Starter
- baja altura;
- verde clásico;
- compacta;
- común.

## 2. Easy Leaf
- hojas amplias;
- verde claro;
- forma redondeada.

## 3. City Green
- vertical;
- compacta;
- verde frío.

## 4. Amber Mist
- tonos oliva/ámbar;
- copa abierta.

## 5. Neon Dream
- verde profundo;
- leves acentos cyan/neón;
- silueta angular.

## 6. Velvet Leaf
- hoja oscura;
- estructura densa;
- aspecto aterciopelado.

## 7. Midnight
- verde casi negro;
- tonos azul profundo;
- copa estrecha.

## 8. Golden Haze
- verde cálido;
- flores con acentos dorados estilizados.

## 9. Urban Legend
- grande;
- equilibrada;
- silueta reconocible y premium.

## 10. Emerald Crown
- copa alta;
- geometría tipo corona;
- verde esmeralda.

## 11. Black Velvet
- tonos oscuros;
- volumen denso;
- silhouette premium.

## 12. Aurora Prime
- forma elegante;
- tintes verdes/teal/violeta muy sutiles;
- legendary.

---

# 12. Personajes

## 12.1 Estilo

- semi-cartoon;
- anatomía simplificada;
- proporciones creíbles;
- manos/cabeza ligeramente mayores;
- siluetas fuertes;
- expresiones claras;
- ropa contemporánea;
- diversidad visual.

## 12.2 Escala

El personaje debe leerse bien en móvil.

Detalles faciales se simplifican.

## 12.3 Render

Preferencia:
- 3D estilizado o pseudo-3D prerenderizado;
- si se usa 2D, mantener volumen y lighting consistente.

---

# 13. Avatar del jugador

MVP:
- cuerpo base masculino/femenino/neutral;
- 6 tonos de piel;
- 8 peinados;
- 6 tops;
- 4 bottoms;
- 4 zapatos;
- 4 accesorios.

No requiere sistema profundo de character creator en VS-01.

---

# 14. Milo Green

NPC mentor.

Visual:
- 30–40 años;
- look relajado;
- streetwear limpio;
- chaqueta ligera;
- gorra opcional;
- barba corta opcional;
- postura segura;
- expresión cercana;
- no hippie estereotípico;
- no parecer personaje existente.

Necesita:
- portrait neutral;
- happy;
- concerned;
- impressed;
- pointing;
- thumbs up.

---

# 15. Employees

Arquetipos MVP:

1. Grower.
2. Technician.
3. Seller.
4. Manager.
5. Researcher.
6. Logistics.

Cada uno:
- silueta;
- color coding sutil;
- outfit;
- icono;
- portrait;
- idle animation;
- work animation.

---

# 16. Entorno VS-01

Una sola habitación: **Starter Growroom**.

Componentes:
- shell;
- suelo;
- dos paredes visibles;
- puerta;
- ventana opcional;
- panel eléctrico;
- grow rack;
- 2 crop slots;
- luz;
- ventilación;
- storage shelf;
- table;
- small terminal;
- crate;
- chair/stool;
- branded poster;
- clutter ligero.

Debe parecer:
- pequeño;
- funcional;
- mejorable;
- aspiracional.

---

# 17. Evolución visual del growroom

## Tier 0
- improvisado;
- simple;
- cables visibles;
- poco espacio.

## Tier 1
- más limpio;
- better lights;
- storage.

## Tier 2
- modular racks;
- better environment control;
- workstation.

## Tier 3
- professional;
- premium materials;
- branded space.

---

# 18. Upgrade visualization

Cada upgrade importante debe producir feedback visible.

Ejemplos:

Lights:
- fixture cambia.

Storage:
- shelf mejora.

Environment:
- unit visible.

Tables:
- rack aumenta.

Workstation:
- terminal más avanzada.

Nunca permitir mejoras puramente numéricas invisibles cuando exista una opción visual barata.

---

# 19. UI Design System

## 19.1 Filosofía

UI:
- moderna;
- compacta;
- táctil;
- legible;
- premium;
- clara.

No:
- skeuomorphism;
- exceso de neón;
- demasiados gradientes;
- paneles saturados.

---

# 20. Tipografía

Sistema:

Display:
- sans geométrica con personalidad.

UI:
- sans altamente legible.

Números:
- tabular cuando corresponda.

Máximo:
- 2 familias.

---

# 21. Grid

Base:
- 8 pt.

Spacing:
- 4 / 8 / 12 / 16 / 24 / 32 / 48.

Radii:
- 8–16 px.

Touch target:
- mínimo 44 px.

---

# 22. HUD

Superior:
- Level.
- Cash.
- Green Credits.
- Reputation.

Inferior:
- Business.
- Market.
- Phone.
- Club.
- Profile.

Contextual:
- crop action;
- timer;
- harvest;
- upgrade.

---

# 23. Cards

Tipos:
- genetic card;
- contract card;
- employee card;
- upgrade card;
- mission card;
- event card;
- club card.

Cada card incluye:
- icon/portrait;
- title;
- primary stat;
- state;
- CTA;
- rarity/status.

---

# 24. Phone UI

El teléfono es interfaz narrativa.

Apps:
- Messages.
- Contacts.
- Contracts.
- Market.
- Club.
- Events.

Estética:
- dark glass;
- minimal;
- tactile;
- subtle branding.

---

# 25. Iconografía

Estilo:
- simple;
- bold;
- rounded geometric;
- 2px/2.5px line equivalent;
- fill para estados activos.

Categorías:
- currency;
- time;
- quality;
- yield;
- reputation;
- XP;
- traits;
- employees;
- building;
- club;
- event.

---

# 26. Animation language

## UI
- 120–220 ms.
- ease-out.
- no rebotes excesivos.

## Gameplay
- plant placement;
- subtle growth pulse;
- ready glow;
- harvest burst;
- reward fly-up;
- upgrade transformation.

## Characters
- idle;
- walk short;
- inspect;
- work;
- celebrate.

---

# 27. VFX

VS-01:
- plant placement dust;
- ready pulse;
- harvest particles;
- cash reward;
- XP reward;
- upgrade flash;
- level-up burst.

MVP:
- rarity effects;
- season effects;
- club contribution;
- market event;
- premium unlock.

---

# 28. Audio

## UI
- tap;
- confirm;
- cancel;
- reward;
- purchase;
- level up.

## Environment
- HVAC hum;
- electrical ambience;
- subtle room tone.

## Gameplay
- plant;
- harvest;
- upgrade;
- machine loop.

## Music
- lo-fi;
- chill electronic;
- urban;
- subtle organic instrumentation.

---

# 29. Asset formats

## Static images
- WebP.
- PNG only when alpha lossless is required.
- SVG for UI icons.

## Animation
- WebP sequence / spritesheet for simple 2D.
- GLB if using 3D pipeline.
- Spine only if justified.

## Audio
- OGG primary.
- AAC fallback if needed.

---

# 30. Target sizes

UI icon:
- source 256×256.
- runtime 64–128 px.

Portrait:
- source 1024×1024.
- runtime 256–512 px.

Item card art:
- source 1024×1024.

Environment prop:
- source according to atlas budget.

Marketing/key art:
- 4096 px master.

---

# 31. Texture budget

VS-01:
- base atlas: 2048×2048.
- props atlas: 2048×2048.
- plants atlas: 2048×2048.
- UI icons: SVG where possible.
- portraits: separate compressed WebP.

Avoid dozens of separate textures.

---

# 32. Naming convention

```text
env_growroom_wall_a_v01.webp
env_growroom_floor_a_v01.webp

prop_rack_basic_a_v01.webp
prop_light_basic_a_v01.webp

plant_greenstarter_stage01_v01.webp
plant_greenstarter_stage02_v01.webp

char_milo_portrait_neutral_v01.webp

ui_icon_cash_v01.svg
ui_card_contract_bg_v01.webp

vfx_harvest_burst_v01.webp
```

---

# 33. Folder structure

```text
assets/
├── environment/
│   ├── growroom/
│   └── city/
├── props/
├── plants/
├── characters/
│   ├── player/
│   ├── npcs/
│   └── employees/
├── ui/
│   ├── icons/
│   ├── cards/
│   ├── hud/
│   └── phone/
├── vfx/
├── animation/
├── audio/
│   ├── music/
│   ├── ui/
│   └── ambience/
└── marketing/
```

---

# 34. VS-01 Asset Manifest

## Environment
1. growroom shell.
2. floor.
3. wall A.
4. wall B.
5. door.
6. small window.
7. electrical panel.
8. basic grow rack.
9. basic lamp.
10. ventilation unit.
11. storage shelf.
12. small table.
13. terminal.
14. stool.
15. crate.
16. wall poster.
17. generic clutter set.

## Crop
18. empty pot/slot.
19–23. Green Starter stages 1–5.
24–28. Easy Leaf stages 1–5.
29. ready indicator.
30. care indicator.

## Character
31. Milo portrait neutral.
32. Milo portrait happy.
33. Milo portrait concerned.
34. Milo portrait impressed.

## UI
35. cash icon.
36. XP icon.
37. reputation icon.
38. time icon.
39. quality icon.
40. yield icon.
41. plant CTA.
42. harvest CTA.
43. contract CTA.
44. upgrade CTA.
45. HUD background.
46. bottom nav.
47. contract card.
48. genetic card.
49. upgrade card.
50. modal.
51. progress bar.
52. timer component.
53. phone frame.
54. message bubble styles.

## VFX
55. plant placement.
56. ready pulse.
57. harvest burst.
58. cash fly-up.
59. XP fly-up.
60. upgrade flash.
61. level-up burst.

## Audio
62. UI tap.
63. UI confirm.
64. UI reward.
65. plant sound.
66. harvest sound.
67. upgrade sound.
68. HVAC loop.
69. room ambience.
70. music loop A.

**VS-01 objetivo: ~70 assets únicos.**

---

# 35. MVP Asset Manifest — estimación

## Environment
- 1 district overview.
- 4 growroom visual tiers.
- 40–60 props.
- 20 decor items.
- 10 structural variants.

## Plants
12 genetics × 5 visual stages:
60 plant states.

Optimizable mediante shared geometry + tint/material variants.

## Characters
- player base.
- Milo.
- 6 employees.
- 8–12 NPC.
- 4–6 poses/animations relevantes por archetype.

## UI
80–120 icons/components/illustrations.

## VFX
20–30.

## Audio
30–50 SFX.
5–8 music tracks/loops.

**MVP aproximado: 250–400 production assets**, según reutilización.

---

# 36. Asset priority

P0:
- todo VS-01;
- UI funcional;
- 2 genetics;
- growroom;
- Milo.

P1:
- 12 genetics;
- upgrades visibles;
- employees;
- extended UI.

P2:
- decoration;
- events;
- clubs;
- store;
- marketing variants.

---

# 37. AI image generation pipeline

IA se usará principalmente para:
- concept art;
- paintovers;
- portraits;
- prop ideation;
- UI mood exploration;
- marketing concepts.

No se debe generar cada asset de forma aislada sin control estilístico.

Pipeline:

1. Master style sheet.
2. Reference board.
3. Prompt master.
4. Character consistency sheet.
5. Environment consistency sheet.
6. Generate.
7. Select.
8. Cleanup.
9. Vectorize/retopologize/redraw if needed.
10. Export runtime.
11. QA.

---

# 38. Prompt Master — Environment

```text
Create a premium stylized isometric 2.5D game environment for GREENBUSINESS, an adult social business tycoon.

Scene: compact starter indoor botanical growroom, viewed from a clean isometric angle, two visible walls, dark charcoal architecture, warm cream accents, deep botanical green, subtle amber and cyan technology highlights.

Art direction: stylized realism, clean readable shapes, premium management-game quality, compact diorama composition, controlled detail, soft shadows, cinematic but gameplay-readable lighting, polished materials, modern urban startup aesthetic mixed with biotech/agrotech design.

Include: modular grow rack, two crop stations, LED grow light, ventilation system, compact storage shelf, small workstation, electrical panel, subtle branded poster, believable clutter.

Avoid: photorealism, childish cartoon style, marijuana-leaf logos everywhere, grunge, criminal imagery, excessive neon, cyberpunk overload, visual clutter, fisheye perspective, text, watermarks.

The result must read clearly at mobile game scale and leave clean interaction space around crop slots.
```

---

# 39. Prompt Master — Plant

```text
Create a stylized premium botanical plant asset for the game GREENBUSINESS.

Genetic: [GENETIC NAME]
Growth stage: [STAGE]

Visual traits:
[TRAITS]

Art direction: stylized realism, clean silhouette, readable at small mobile-game scale, premium isometric management game asset, controlled foliage detail, believable but fictional morphology, rich botanical color, subtle material response.

Camera and lighting must match the GREENBUSINESS growroom asset library.

Transparent background. Centered asset. No pot unless specified. No text. No watermark. No photorealism. No exaggerated fantasy magic.
```

---

# 40. Prompt Master — Character Portrait

```text
Character portrait for GREENBUSINESS, premium adult social business tycoon.

Character: [NAME]
Role: [ROLE]
Expression: [EXPRESSION]

Style: stylized semi-realistic game character, strong silhouette, contemporary urban fashion, slightly exaggerated proportions, premium mobile/PC management-game illustration, clean controlled rendering, expressive face, mature but approachable.

Palette compatible with dark botanical green, charcoal, cream, muted gold and subtle neon accents.

Background: simple dark gradient or transparent.

Avoid: anime, children's cartoon proportions, hyperreal photography, existing TV/game character resemblance, text, logos, watermark.
```

---

# 41. Prompt Master — UI Card

```text
Design a premium game UI card for GREENBUSINESS.

Component: [TYPE]
Purpose: [PURPOSE]

Visual system: dark charcoal base, warm cream typography areas, deep botanical green, subtle gold for premium/progression, restrained cyan/neon green active accents.

Style: clean contemporary mobile/PC management game UI, compact hierarchy, excellent readability, 8pt grid, rounded geometry, minimal glass effect, high-end biotech/agrotech brand language.

Avoid: casino UI, glossy free-to-play clutter, excessive gradients, excessive borders, tiny text, skeuomorphism, cartoon cannabis imagery.
```

---

# 42. Consistency rules for AI generation

Every generated asset must preserve:
- same isometric camera;
- same light direction;
- same shadow softness;
- same material roughness language;
- same saturation range;
- same detail density;
- same scale family.

A visually attractive asset that breaks consistency is rejected.

---

# 43. Art QA checklist

An asset passes only if:
- silhouette reads at target size;
- palette matches;
- camera matches;
- lighting matches;
- no unwanted text;
- no watermark;
- no anatomy errors;
- no impossible geometry;
- no accidental logos/IP;
- export naming correct;
- dimensions correct;
- alpha correct;
- optimized;
- source retained.

---

# 44. Legal/IP rules

Do not reproduce:
- characters;
- names;
- logos;
- UI;
- props;
- screenshots;
- branding;
- locations

from Weeds Social Club or any TV property.

GreenBusiness is a spiritual successor only at the level of:
- social management;
- appointment gameplay;
- cultivation loop;
- progression.

All expression must be original.

---

# 45. Marketing art

MVP marketing needs:

1. Key art.
2. Logo lockup.
3. App icon.
4. Store hero.
5. Portrait promo.
6. 3 screenshots.
7. Vertical ad template.
8. Social thumbnail template.

Key art concept:

Foreground:
- player/manager.

Midground:
- premium growroom.

Background:
- larger future empire/city hints.

Message:
small room → big empire.

---

# 46. Logo

Wordmark:
**GREENBUSINESS**

Desired:
- strong;
- modern;
- premium;
- business-forward;
- subtle botanical cue.

Avoid:
- giant cannabis leaf;
- reggae cliché;
- green gradient startup logo;
- dispensary branding cliché.

---

# 47. App icon

Concept:
- stylized green sprout/leaf fused with upward business graph or monogram GB.

Must read at:
- 32 px;
- 64 px;
- 128 px.

---

# 48. Production workflow

For each asset:

`CONCEPT → APPROVAL → SOURCE → RUNTIME EXPORT → QA → INTEGRATION`

Statuses:
- TODO
- CONCEPT
- APPROVED
- IN_PRODUCTION
- QA
- DONE
- REJECTED

---

# 49. Asset manifest schema

Cada asset debe registrarse así:

```json
{
  "id": "plant_greenstarter_stage03",
  "category": "plant",
  "scope": "VS01",
  "priority": "P0",
  "status": "TODO",
  "source_format": "PSD_OR_GLTF",
  "runtime_format": "WEBP",
  "target_size": "512x512",
  "transparent": true,
  "animation": false,
  "dependencies": [],
  "notes": ""
}
```

---

# 50. Asset tracking columns

- ID
- Name
- Category
- Scope
- Priority
- Status
- Owner
- Source
- Runtime format
- Dimensions
- Animated
- Dependencies
- Prompt ID
- Version
- Review date
- Notes

---

# 51. Performance budgets

VS-01:
- first-load visual assets ≤15 MB ideal;
- critical scene assets ≤8 MB;
- audio initial ≤5 MB;
- lazy-load portraits and secondary UI.

MVP:
- chunk by system;
- chunk by district;
- chunk by genetic family;
- no monolithic atlas for all content.

---

# 52. Source asset policy

Conservar:
- layered original;
- prompt;
- generation seed if available;
- reference images;
- edit history;
- license/source provenance.

No meter assets directamente desde output IA sin revisión.

---

# 53. VS-01 Visual Acceptance Criteria

El vertical slice visual se considera válido si:

1. La habitación se entiende en <2 segundos.
2. Los dos crop slots son evidentes.
3. El jugador distingue growing vs ready sin leer texto.
4. Green Starter y Easy Leaf se distinguen.
5. Harvest produce feedback claro.
6. Primera mejora cambia visualmente la habitación.
7. Milo tiene identidad propia.
8. HUD funciona a 390 px de ancho.
9. No existen elementos visuales que recuerden directamente a Weeds Social Club.
10. El resultado parece una IP original y comercializable.

---

# 54. MVP Visual Acceptance Criteria

- 12 genéticas diferenciables.
- 4 estados visuales de growroom.
- 6 employee archetypes.
- 8+ NPC.
- UI consistente.
- 40+ decor assets.
- visual feedback para rarity.
- club UI.
- market UI.
- event skins.
- store assets.
- marketing kit.

---

# 55. Qué NO producir todavía

No crear antes de validar VS-01:

- ciudad completa;
- múltiples districts terminados;
- 100+ decor assets;
- 3D open world;
- cinematic intro;
- 20+ NPC detallados;
- vehicles;
- second city;
- franchise environments;
- seasonal art packs;
- full breeding visualization;
- advanced lab.

---

# 56. Canon visual final

A partir de este documento:

- GreenBusiness usa estilo stylized premium isometric 2.5D.
- El growroom es el escenario central del VS-01.
- El primer vertical slice usa ~70 assets.
- El MVP apunta a 250–400 assets con reutilización.
- AI se usa como acelerador de producción, no como sustituto del control artístico.
- La consistencia visual tiene prioridad sobre la cantidad.
- Toda mejora importante debe intentar producir feedback visual.
- Las genéticas se diferencian visualmente.
- UI y mundo comparten una identidad biotech/agrotech urbana premium.
- La IP debe permanecer claramente independiente de Weeds Social Club.
