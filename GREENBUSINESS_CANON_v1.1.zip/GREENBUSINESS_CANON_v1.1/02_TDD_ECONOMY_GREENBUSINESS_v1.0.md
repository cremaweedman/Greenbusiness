# GREENBUSINESS — Technical Design + Economy Design v1.0

## 1. Stack
Cliente: Next.js, TypeScript, Phaser, Zustand, TanStack Query, Tailwind, PWA.  
Backend: Python 3.13+, FastAPI, SQLAlchemy 2, Alembic, Pydantic v2, PostgreSQL, Redis, Dramatiq.  
Infra: Docker, Docker Compose, Nginx, Cloudflare, S3/R2, GitHub Actions, Sentry, OpenTelemetry, PostHog.

Arquitectura: modular monolith.

## 2. Reglas
- Servidor autoritativo.
- Economía transaccional.
- Timers calculados, no jobs por objeto.
- Contenido data-driven.
- Toda acción económica auditable.

## 3. Dominios
Auth, Player, Crops, Genetics, Inventory, Economy, Contracts, Progression, Employees, Clubs, Missions, LiveOps, Payments, Analytics, Antifraud, Notifications.

## 4. Entidades
User, PlayerProfile, Wallet, LedgerEntry, Genetic, GeneticTrait, CropSlot, CropInstance, InventoryItem, Contract, PlayerContract, Facility, Upgrade, PlayerUpgrade, Skill, PlayerSkill, Employee, PlayerEmployee, Mission, Club, ClubMember, LiveOpsEvent, OutboxEvent.

## 5. Timers
Las plantas almacenan started_at y ready_at. PostgreSQL es source of truth. Redis no contiene balances ni estado permanente.

## 6. Economy ledger
Cada movimiento registra user, currency, amount, source, balance_before, balance_after, idempotency_key y metadata. El ledger nunca se borra.

## 7. Fórmulas
Quality = base + genetic_roll + care_bonus + facility_bonus + skill_bonus + employee_bonus, clamp 0–100.

Yield = base_yield × facility_multiplier × skill_multiplier × employee_multiplier × event_multiplier.

## 8. Monedas
Cash: soft currency.
Green Credits: premium.

## 9. Economy pacing
- Primera mejora: ~5 min.
- Segundo slot: 15–25 min.
- Primer empleado: D1–D2.
- Primera especialización: D2.
- Primer upgrade caro: D3–D4.
- Club antes de D3.

## 10. Contratos
3 standard + 1 specialised. Refresh cada 4 horas. Máximo 3 contratos aceptados simultáneamente.

## 11. Market
Multiplicadores 0.75–1.40 y mean reversion hacia 1.0. Actualización cada 6 horas.

## 12. Skill tree
Botany: costes de semilla, quality, yield.
Business: reward, offers, reputation.
Operations: grow time, employees, storage, automation.

## 13. Slots
2 iniciales.
Nivel 3→3, 5→4, 8→5, 12→6, 16→8, 20→10.

## 14. Seguridad
JWT 15 min, refresh 30 días con rotation, Argon2id, rate limiting, CSP, HSTS, SQL constraints, audit logs y secret manager en producción.

## 15. Observabilidad
API p50/p95/p99, 5xx, DB, Redis, queue depth, economy failures, payments y active users.

## 16. Performance
Read p95 <250 ms.
Mutations p95 <400 ms.
LCP <2.5 s.

## 17. Testing
pytest, pytest-asyncio, Vitest, React Testing Library, Playwright. Tests críticos: duplicate harvest, double contract completion, negative wallet, race conditions, duplicate payment e inventory over-consumption.

## 18. Orden de implementación
Sprint 0 repo/CI/Docker/Postgres/Redis/FastAPI/Next.
Sprint 1 auth/profiles.
Sprint 2 wallet/ledger/idempotency.
Sprint 3 genetics/crops/timers/harvest.
Sprint 4 inventory/quality/yield/game scene.
Sprint 5 contracts/rewards/progression.
Sprint 6 upgrades/skills.
Sprint 7 missions/tutorial.
Sprint 8 analytics/admin/remote config.
Sprint 9 employees.
Sprint 10 clubs.
Sprint 11 store/premium.
Sprint 12 LiveOps.
